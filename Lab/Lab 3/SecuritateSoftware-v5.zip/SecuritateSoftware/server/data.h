#ifndef _DATA_H_
#define _DATA_H_

#include <windows.h>
#include "..\\utils\\utils.h"

extern DWORD gUserCount;
extern USER_DATA gUserData[10];

#endif _DATA_H_
