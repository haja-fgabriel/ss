#include "data.h"

DWORD gUserCount = 10;

USER_DATA gUserData[10] = 
{
    { "raul",       "Raul Tosa",    "raul@cs.ubbcluj.ro",       "P@ssw0rd"  },
    { "dan",        "Dan Popa",     "dan@cs.ubbcluj.ro",        "parola"    },
    { "pop",        "Pop Iustin",   "pop@cs.ubbcluj.ro",        "pop"       },
    { "popa",       "Popa Ioana",   "popa@cs.ubbcluj.ro",       "popescu"   },
    { "popescu",    "Popescu Ion",  "popescu@cs.ubbcluj.ro",    "popa"      },
    { "ana",        "Ana Ionescu",  "ana@cs.ubbcluj.ro",        "password"  },
    { "daniel",     "Daniel Pop",   "daniel@cs.ubbcluj.ro",     "daniel"    },
    { "ion",        "Ion Dinescu",  "ion@cs.ubbcluj.ro",        "qwerty"    },
    { "admin",      "Admin Admin",  "admin@cs.ubbcluj.ro",      "admin"     },
    { "ionescu",    "Ionescu Ana",  "ionescu@cs.ubbcluj.ro",    "123456"    },
};
