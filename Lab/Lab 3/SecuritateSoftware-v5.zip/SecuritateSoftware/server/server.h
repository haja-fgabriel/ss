#ifndef _SERVER_H_
#define _SERVER_H_

#define DEFAULT_BUFLEN  0x4000

void
Log(
    const char *Format,
    ...
    );

#endif _SERVER_H_
